package com.cg.dao;

import java.util.List;

import com.cg.dto.CarDTO;

public class CarDAOIMPL implements CarDAO{

	@Override
	public List<CarDTO> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CarDTO findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void create(CarDTO car) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(CarDTO car) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(String[] ids) {
		// TODO Auto-generated method stub
		
	}

}
