package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.dto.CarDTO;

public class CarDAOIMPL implements CarDAO {

	Map<Integer, CarDTO> map = null;

	public CarDAOIMPL() 
	{
	map=new HashMap<Integer,CarDTO>();
	}

	@Override
	public List<CarDTO> findAll() {
		// TODO Auto-generated method stub
		List<CarDTO> carList=new ArrayList<CarDTO>(map.values());
		System.out.println("inside find all:"+carList);
		return carList;
	}

	@Override
	public CarDTO findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void create(CarDTO car) {
		// TODO Auto-generated method stub
		CarDTO c=map.putIfAbsent(car.getId(),car);

	}

	@Override
	public void update(CarDTO car) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(String[] ids) {
		// TODO Auto-generated method stub

	}

}
