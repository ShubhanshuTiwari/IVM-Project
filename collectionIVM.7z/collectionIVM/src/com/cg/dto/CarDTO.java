package com.cg.dto;

//Follow TODOs (if available)
/**
 * 
 * This is a CarDTO class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public class CarDTO
{
    private int id;
    private String make;
    private String model;
    private String modelYear;

    public CarDTO()
    {
        //TODO 1 initialize id to -1 and rest of the member variables to a blank string
    	this.id=-1;
    	this.make="";
    	this.model="";
    	this.modelYear="";
		
    }

    //TODO 2 Implement the setter and getter methods
    
    
    
    
}
